import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { TodoService } from './../../services/todo.service';
import { Observable } from 'rxjs/Rx';
import { todo } from './../../models/todo.model';

@Component({
    selector: 'app-list',
    templateUrl: './list.component.html',
    styleUrls: ['./list.component.css']
})

export class ListComponent implements OnInit {
    public todoSub: Observable<todo>;
    @ViewChild('deleteModal')
    deleteModal: ElementRef;
    deleteId;
    constructor( private router: Router, private todoService:TodoService ) {

    }

    ngOnInit() {

      this.todoSub = this.todoService.list();

    }

    editRecord(id) {
        console.log('Edit record ID>>>', id);
        this.router.navigate(['/edit', id]);
    }

    deleteRecord() {
      if(this.deleteId !== undefined){
        this.todoService.remove(this.deleteId);
        this.deleteModal.nativeElement.style.display = 'none'; 
      }
      
    }
    //popUp Open
    onClickOpenModel(deleteData){
      this.deleteId = deleteData;
      this.deleteModal.nativeElement.style.display = 'block';
    }
    onClickCloseModal(){
         this.deleteId = undefined;
         this.deleteModal.nativeElement.style.display = 'none';      
    }

    public trackByToodFun(index, item) {
      return item.id;
    }
}
