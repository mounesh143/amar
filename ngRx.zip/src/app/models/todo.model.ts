
export interface todo {
  id?: number,
  name: string;
  age:number;
  address: string;
}
