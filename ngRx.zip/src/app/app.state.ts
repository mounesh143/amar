
import { todo } from './models/todo.model'

export interface AppState {
  readonly tutorial: todo[];
}
